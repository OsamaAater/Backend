package com.example.backendtestproject.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import java.sql.Timestamp;

@Entity
public class ApplicationInfo {

    @Id
    @GeneratedValue
    private Integer appInfoUid;

    private String appInfoDescription;

    private Timestamp createdAt;

    private String createdBy;

    private Timestamp modifiedAt;

    private String modifiedBy;

    // Constructors, getters, and setters

    public Integer getAppInfoUid() {
        return appInfoUid;
    }

    public void setAppInfoUid(Integer appInfoUid) {
        this.appInfoUid = appInfoUid;
    }

    public String getAppInfoDescription() {
        return appInfoDescription;
    }

    public void setAppInfoDescription(String appInfoDescription) {
        this.appInfoDescription = appInfoDescription;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getModifiedAt() {
        return modifiedAt;
    }

    public void setModifiedAt(Timestamp modifiedAt) {
        this.modifiedAt = modifiedAt;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
}