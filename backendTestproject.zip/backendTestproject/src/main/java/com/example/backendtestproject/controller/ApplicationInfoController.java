package com.example.backendtestproject.controller;

import com.example.backendtestproject.model.ApplicationInfo;
import com.example.backendtestproject.repository.ApplicationInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:5173")
public class ApplicationInfoController {

    @Autowired
    private ApplicationInfoRepository applicationInfoRepository;

    @PostMapping("/appinfo")
    ApplicationInfo newApplicationInfo(@RequestBody ApplicationInfo newApplicationInfo) {
        return applicationInfoRepository.save(newApplicationInfo);
    }

    @GetMapping("/appinfos")
    List<ApplicationInfo> getAllApplicationInfo() {
        return applicationInfoRepository.findAll();
    }
}